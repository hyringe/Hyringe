# Proof of Concept for HvCreateVp/HvDeleteVp-"Aging"-Crash

## Description

This PoC repeatedly issues pairs of HvCreateVp/HvDeleteVp hypercalls, until the system eventually crashes, showing a "Hypervisor Error" BSOD.

The PoC has to be executed in the root partition.
A guest partition has to be running.
The partition ID of the VM and the number of virtual processor to create and delete has to be known.

The crash has been reproduced multiple times with a virtual machine with 4 virtual processors.

## Execution

### Test HvCreateVp

Modify the first two lines of `campaigns/test_createvp.hycall`, such that partition ID of the guest partition is assigned to `PID` and the virtual processor ID to be created is assigned to `VPI`.
In previous runs of this PoC, the first free processor ID was used (4 virtual processors in guest partition -> cores 0,1,2,3 are already created, set `VPI` to 4).

To now check if a HvCreateVp call can be performed successfully, compile the human-readable campaign into a binary campaign:
```
java -jar hycallcompiler.jar campaigns/test_createvp.hycall hyperv-compile campaigns/test_createvp.bin
```
Let the campaign be executed by the hypercall injection driver, logging the result value of the hypercall:
```
.\nonpnpapp.exe campaigns/test_createvp.bin --result
```
The log is stored in `campaigns/test_createvp.bin.out`.
Print it with:
```
java -jar hycallcompiler.jar campaigns/test_createvp.hycall hyperv-report-console campaigns/test_createvp.bin.out
```
If the result value is `0`, HvCreateVp was successfull.
In our testing, it was possible to create one more virtual processor than the VM was specified to have.

### Test HvDeleteVp

This is only possible after successfully testing HvCreateVp.
Again, modify the first two lines of `campaigns/test_createvp.hycall`, such that `PID` and `VPI` match the values used in HvCreateVp.

To now check if a HvDeleteVp call can be performed successfully on the newly created VP, compile the human-readable campaign into a binary campaign:
```
java -jar hycallcompiler.jar campaigns/test_deletevp.hycall hyperv-compile campaigns/test_deletevp.bin
```
Let the campaign be executed by the hypercall injection driver:
```
.\nonpnpapp.exe campaigns/test_deletevp.bin --result
```
Print it:
```
java -jar hycallcompiler.jar campaigns/test_deletevp.hycall hyperv-report-console campaigns/test_deletevp.bin.out
```
If the result value is `0` the deletion was successfull.
If the VP was created successfully beforehand, the deletion should not fail, according to our experience.

### Run the repetition

When it was verified that the hypercalls do perform their work, they can be repeated in fast succession.
Again, modify the first two lines of `campaigns/vp_aging.hycall`, such that `PID` and `VPI` match the values tested before.

Compile the campaign:
```
java -jar hycallcompiler.jar campaigns/vp_aging.hycall hyperv-compile campaigns/vp_aging.bin
```
Let the campaign be executed repeatedly by the hypercall injection driver:
```
.\nonpnpapp.exe campaigns/vp_aging.bin --repeat
```
This should eventually crash the system.

In our testing, we logged the number of campaign executions without crash (10000 creates/deletes per campaign):
91, 76, 632, 293, 224, 48, 196, 309, 2480, 644, 580, 1645, 8721 
