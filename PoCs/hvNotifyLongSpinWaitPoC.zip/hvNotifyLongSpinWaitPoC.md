# Proof of Concept for HvNotifyLongSpinWait-Hypercall-Crash

## Description

This PoC issues a single HvNotifyLongSpinWait hypercall.
When executed in the root partition, this causes the system to crash

## Execution

Run:
```
nonpnpapp.exe hvnotifylongspinwait.bin
```

## Details about the Execution

`nonpnpapp.exe` loads the `nonpnp.sys` driver.
Then, it issues a write call, with the write buffer containing the filepath of the hypercall campaign.
The driver's responsible IRP handler retrieves the filepath and starts reading and executing hypercalls described in the file.
In this case, this is a single HvNotifyLongSpinWait call, which causes the crash.

The file `hvnotifylongspinwait.hycall` is not needed for the PoC, but provides a human-readable version of the binary campaign `hvnotifylongspinwait.bin`.
